#include "game.h"
#include "gameConfig.h"
#include"CMUgraphicsLib/auxil.h"
#include <iostream>
#include<chrono>

using namespace chrono;
using namespace std;
int elapsedTime = 0;
string game::formatTime(int seconds) const {
	int hours = seconds / 3600;
	int minutes = (seconds % 3600) / 60;
	int secs = seconds % 60;

	stringstream ss;
	ss << setfill('0') << setw(2) << hours << ":"
		<< setfill('0') << setw(2) << minutes << ":"
		<< setfill('0') << setw(2) << secs;

	return ss.str();
}

void game::switchGamemode(int GameModeChoice)
{
	if (GameModeChoice == 0) { gameMode = MODE_PLAY; }
	else if (GameModeChoice == 1) { gameMode = MODE_STOP; }
	else if (GameModeChoice == 2) { gameMode = MODE_PLAY; }
	else if (GameModeChoice == 3) { gameMode = MODE_FINISH; }
}


game::game()
{
	//Initialize playgrond parameters
	gameMode = MODE_DSIGN;
	live = new Lives;
	score = 0;
	//1 - Create the main window
	pWind = CreateWind(config.windWidth, config.windHeight, config.wx, config.wy);

	//2 - create and draw the toolbar
	point toolbarUpperleft;
	toolbarUpperleft.x = 0;
	toolbarUpperleft.y = 0;

	gameToolbar = new toolbar(toolbarUpperleft,0,config.toolBarHeight, this);
	gameToolbar->draw();

	//3 - create and draw the grid
	point gridUpperleft;
	gridUpperleft.x = 0;
	gridUpperleft.y = config.toolBarHeight;
	bricksGrid = new grid(gridUpperleft, config.windWidth, config.gridHeight, this);
	bricksGrid->draw();
	
	//4- Create the Paddle
	point paddleUpperleft;
	paddleUpperleft.x = (config.windWidth / 2) + config.wx - (config.paddleWidth / 2);
	paddleUpperleft.y = config.windHeight - 2 * config.paddleHeight;
	pad = new paddle(paddleUpperleft, config.paddleWidth, config.paddleHeight, this);
	pad->draw();

	//5- Create the ball
	point BallUpperleft;
	BallUpperleft.x = config.Ballx0;
	BallUpperleft.y = config.Bally0; /////modification
	GameBall = new Ball(BallUpperleft, 2 * config.BallRad, 2 * config.BallRad, this);
	
	collectable = nullptr;

	//6- Create and clear the status bar
	clearStatusBar();
	
	
}

game::~game()
{
	delete pWind;
	delete gameToolbar;
	delete bricksGrid;
	delete pad;
}



clicktype game::getMouseClick(int& x, int& y) const
{
	return pWind->WaitMouseClick(x, y);	//Wait for mouse click
}
//////////////////////////////////////////////////////////////////////////////////////////
window* game::CreateWind(int w, int h, int x, int y) const
{
	window* pW = new window(w, h, x, y);
	pW->SetBrush(config.bkGrndColor);
	pW->SetPen(config.bkGrndColor, 1);
	pW->DrawRectangle(0, 0, w, h);
	return pW;
}
//////////////////////////////////////////////////////////////////////////////////////////
void game::clearStatusBar() const
{
	//Clear Status bar by drawing a filled rectangle
	pWind->SetPen(config.statusBarColor, 1);
	pWind->SetBrush(config.statusBarColor);
	pWind->DrawRectangle(0, config.windHeight - config.statusBarHeight, config.windWidth, config.windHeight);
}

//////////////////////////////////////////////////////////////////////////////////////////

void game::printMessage(string msg) const	//Prints a message on status bar
{
	clearStatusBar();	//First clear the status bar

	pWind->SetPen(config.penColor, 50);
	pWind->SetFont(24, BOLD, BY_NAME, "Arial");
	pWind->DrawString(10, config.windHeight - (int)(0.85 * config.statusBarHeight), msg);
}



window* game::getWind() const		//returns a pointer to the graphics window
{
	return pWind;
}

paddle* game::getPaddle() const
{
	return pad;
}

Ball* game::getBall() const
{
	return GameBall;
}

brick*** game::getBrickMatrix() const
{
	return bricksGrid->getbrickMatrix();
}


void game::MovePaddle() const
{
	char press;
	pWind->GetKeyPress(press);
	if (press == 6) {
		pad->movepaddleright();
	}
	else if (press == 4) {
		pad->movepaddleleft();
	}
}



string game::getSrting() const
{
	string Label;
	char Key;
	keytype ktype;
	pWind->FlushKeyQueue();
	while (1)
	{
		ktype = pWind->WaitKeyPress(Key);
		if (ktype == ESCAPE)	//ESCAPE key is pressed
			return "";	//returns nothing as user has cancelled label
		if (Key == 13)	//ENTER key is pressed
			return Label;
		if (Key == 8)	//BackSpace is pressed
			if (Label.size() > 0)
				Label.resize(Label.size() - 1);
			else
				Key = '\0';
		else
			Label += Key;
		printMessage(Label);
	}
}

grid* game::getGrid() const
{
	// TODO: Add your implementation code here.
	return bricksGrid;
}

void game::ResetGame()
{
	if ((GameBall->getuprleft().y >= pWind->GetHeight() - (2 * config.BallRad) - 45)) {

		pWind->SetPen(LAVENDER, 1);
		pWind->SetBrush(LAVENDER);
		pWind->DrawCircle(GameBall->getuprleft().x, GameBall->getuprleft().y , config.BallRad);
		if ((live->getnumber_lives()) != 0) {
			GameBall->resetcenter();
			live->livelost();
			pWind->SetPen(LAVENDER,1);
			pWind->SetBrush(LAVENDER);
			pWind->DrawCircle(GameBall->getuprleft().x, GameBall->getuprleft().y - 15, 6*config.BallRad);
		}
			

		else gameMode = MODE_FINISH;
		
	}
}

paddle* game::getpaddle() const
{
	return pad;
}


bool game::CollectableCheck(Collectables* c, paddle* p) {
	bool isCol = false;
	if (!c) {
		return isCol;
	}
	if (c->getuprleft().y >= p->getuprleft().y - config.collecSide && c->getuprleft().y < p->getuprleft().y + config.collecSide) {
		if (c->getuprleft().y == p->getuprleft().y + config.collecSide) {
			delete c;
			c = nullptr;
		}
		else if (c->getuprleft().x >= p->getuprleft().x && c->getuprleft().x <= p->getuprleft().x + config.paddleWidth) {
			/*c->collisionAction();*/
			isCol = true;
			return isCol;
		}
	}
	return isCol;
}

void game::Move_Coll_Pad(Collectables* coll, paddle* padd)
{
	int et = 0;
	if (CollectableCheck(coll, padd) && et!=60 ) {
		clock_t st = clock();
		coll->collisionAction();
		et = (static_cast<int>(st)) / CLOCKS_PER_SEC;
	}
	else {
		MovePaddle();
		et = 0;
	}
}




////////////////////////////////////////////////////////////////////////
//void game::go() 
//{
//	//This function reads the position where the user clicks to determine the desired operation
//	int x, y;
//	keytype ktype;
//	char Key;
//	bool isExit = false;
//
//	//Change the title
//	pWind->ChangeTitle("- - - - - - - - - - Brick Breaker (CIE202-project) - - - - - - - - - -");
//
//	// Draw the game content
//
//
//	do
//	{
//
//		if (gameMode == MODE_DSIGN)		//Game is in the Desgin mode
//		{
//			printMessage("Ready...");
//			getMouseClick(x, y);		//Get the coordinates of the user click
//			//[1] If user clicks on the Toolbar
//			if (y >= 0 && y < config.toolBarHeight)
//			{
//				isExit = gameToolbar->handleClick(x, y);
//			}
//		}
//
//
//		window* pWind1 = getWind();
//		clock_t start_time = clock();
//
//
//		//if (gameMode == MODE_PLAY) {
//		//	
//		//	
//		//	/*bool Space_isPressed = false;*/
//		//	/*printMessage("You can play now  ==> Press space bar to start <==");*/
//		//	/*pWind->FlushKeyQueue();
//		//	ktype = pWind->GetKeyPress(Key);*/
//		//	/*if (Key == 32) {
//		//		Space_isPressed = true;
//		//	}*/
//
//		//	/*if (Space_isPressed = true)*/
//		//	
//		//		/*pWind->FlushKeyQueue();*/
//		//		GameBall->draw(LAVENDER, pWind);
//
//		//		getGrid();
//
//		//		printMessage(" Lives : " + to_string(live->getnumber_lives()) + " | Score : " + to_string(score) + " | Timer : " + formatTime(elapsedTime));
//		//		GameBall->ball_Movement();
//		//		GameBall->draw(RED, pWind);
//		//		ResetGame();
//
//
//		//		pWind->UpdateBuffer();
//		//		Pause(10);
//
//		//		pWind->GetMouseClick(x, y);
//
//		//		MovePaddle();
//		//		if (y >= 0 && y < config.toolBarHeight)
//		//		{
//		//			isExit = gameToolbar->handleClick(x, y);
//		//		}
//		//		elapsedTime = (static_cast<int>(start_time) + 32) / CLOCKS_PER_SEC;
//
//		//}
//
//		if (gameMode == MODE_PLAY) {
//
//			elapsedTime = (static_cast<int>(start_time) + 32) / CLOCKS_PER_SEC;
//			printMessage(" Lives : " + to_string(live->getnumber_lives()) + " | Score : " + to_string(score) + " | Timer : " + formatTime(elapsedTime));
//			ResetGame();
//
//			GameBall->draw(LAVENDER, pWind);
//			
//			GameBall->ball_Movement();
//			/*GameBall->collisionAction();*/
//
//			GameBall->draw(RED, pWind);
//			
//			Pause(10);
//			pWind->GetMouseClick(x, y);
//			MovePaddle();
//			if (y >= 0 && y < config.toolBarHeight)
//			{
//				isExit = gameToolbar->handleClick(x, y);
//			}
//
//
//			this->getGrid()->draw();
//
//		}
//
//
//		if (gameMode == MODE_STOP)
//		{
//			/*getMouseClick(x, y);*/
//			pWind->GetMouseClick(x, y);
//			if (y >= 0 && y < config.toolBarHeight && x >= config.iconWidth * 8)
//			{
//				isExit = gameToolbar->handleClick(x, y);
//			}
//		}
//
//
//		if (gameMode == MODE_FINISH)
//			if (live->getnumber_lives() == 0)
//			{
//				pWind->SetPen(BLACK, 60);
//				pWind->SetFont(36, BOLD, BY_NAME, "Arial");
//				pWind->DrawString(400, config.paddleHeight - 100, "Game Over.  || Score :" + to_string(score));
//				clearStatusBar();
//
//			}
//			else if (!getBrickMatrix()[0][0])
//			{
//				/*string messege;
//				if (config.totalScore)
//				{
//					messege = "You Won  | Final Score :" + to_string(score->getScore());
//				}*/
//				/*else
//				{
//					messege = "Please, Add bricks to start";
//				}*/
//				pWind->SetPen(LIGHTSEAGREEN, 50);
//				pWind->SetFont(35, BOLD, BY_NAME, "Arial");
//				pWind->DrawString(400, config.paddleHeight - 100, "Winner Winner  || Score :" + to_string(score));
//				clearStatusBar();
//
//
//			}
//
//		live->setLives(3);
//		elapsedTime = 0;
//			/*getMouseClick(x, y);
//			pWind->SetPen(LAVENDER);
//			pWind->SetBrush(LAVENDER);
//			pWind->DrawRectangle(0, config.toolBarHeight + config.gridHeight,
//				config.windWidth, config.windHeight - config.statusBarHeight);
//			GameBall->draw(LAVENDER);
//			getGrid();
//			ballGame->Reset();
//			*gameMode = MODE_DSIGN*/;
//		
//
//
//	} while (!isExit);
//	
//}



void game::go()
{
	//This function reads the position where the user clicks to determine the desired operation
	int x, y;


	bool isExit = false;

	//Change the title
	pWind->ChangeTitle("- - - - - - - - - - Brick Breaker (CIE202-project) - - - - - - - - - -");





	// Draw the game content




	do
	{

		if (gameMode == MODE_DSIGN)		//Game is in the Desgin mode
		{
			printMessage("Ready...");
			getMouseClick(x, y);		//Get the coordinates of the user click
			//[1] If user clicks on the Toolbar
			if (y >= 0 && y < config.toolBarHeight)
			{
				isExit = gameToolbar->handleClick(x, y);
			}
		}

		window* pWind1 = getWind();
		clock_t start_time = clock();

		if (gameMode == MODE_PLAY) {
			elapsedTime = (static_cast<int>(start_time) + 32) / CLOCKS_PER_SEC;
			printMessage(" Lives : " + to_string(live->getnumber_lives()) + " | Score : " + to_string(score) + " | Timer : " + formatTime(elapsedTime));
			
			
			GameBall->draw(LAVENDER, pWind);
			GameBall->ball_Movement();
			GameBall->draw(RED, pWind);

			ResetGame();
			Pause(30);
			pWind->GetMouseClick(x, y);
			Move_Coll_Pad(collectable, pad);
			if (collectable != nullptr) {
				collectable->moveCollectable();
			}
			/*MovePaddle();*/
			if (y >= 0 && y < config.toolBarHeight)
			{
				isExit = gameToolbar->handleClick(x, y);
			}
			
			
			this->getGrid()->draw();
			pad->draw();
			gameToolbar->draw();
			bool check = false;
			for (int i = 0; i < (config.gridHeight / config.brickHeight); i++) {
				for (int j = 0; j < (config.windWidth / config.brickWidth); j++)
				{
					if (getBrickMatrix()[i][j] != nullptr) check = true;
				}
			}
			if (!check) gameMode = MODE_FINISH;
			
		}


		if (gameMode == MODE_STOP)
		{
			/*getMouseClick(x, y);*/
			pWind->GetMouseClick(x, y);
			if (y >= 0 && y < config.toolBarHeight && x >= config.iconWidth * 8)
			{
				isExit = gameToolbar->handleClick(x, y);
			}
		}


		if (gameMode == MODE_FINISH) {
			if (live->getnumber_lives() == 0)
			{
				pWind->SetPen(BLACK, 60);
				pWind->SetFont(36, BOLD, BY_NAME, "Arial");
				pWind->DrawString(400, config.paddleHeight + 100, "Game Over.  || Score :" + to_string(score));
				clearStatusBar();

			}

			else 
			{
				pWind->SetPen(LIGHTSEAGREEN, 50);
				pWind->SetFont(35, BOLD, BY_NAME, "Arial");
				pWind->DrawString(400, config.paddleHeight + 100, "Winner Winner  || Score :" + to_string(score));
				clearStatusBar();


			}

			/*live->setLives(3);*/
			elapsedTime = 0;
		}
		
			/*getMouseClick(x, y);
			pWind->SetPen(LAVENDER);
			pWind->SetBrush(LAVENDER);
			pWind->DrawRectangle(0, config.toolBarHeight + config.gridHeight,
				config.windWidth, config.windHeight - config.statusBarHeight);
			GameBall->draw(LAVENDER);
			getGrid();
			ballGame->Reset();
			*gameMode = MODE_DSIGN*/
		

	} while (!isExit);

}
