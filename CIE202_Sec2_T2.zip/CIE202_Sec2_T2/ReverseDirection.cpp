#include "ReverseDirection.h"
#include"game.h"

ReverseDirection::ReverseDirection(point r_uprleft, int r_width, int r_height, game* r_pGame, paddle* p) :Collectables(r_uprleft,r_width, r_height, r_pGame,p) {
	image = "images\\Collectables\\ReverseDirection.jpg";
	setImageName(image);
}
void ReverseDirection::collisionAction()
{
	char key;
	pGame->getWind()->GetKeyPress(key);
	
	if (key == 4) pad->movepaddleright();
	else if (key == 6) pad->movepaddleleft();


}
