#pragma once
#include"Collectables.h"
class QuickSand :public Collectables
{
public:
	QuickSand(point r_uprleft, int r_width, int r_height, game* r_pGame, paddle* p);
	void collisionAction();

};